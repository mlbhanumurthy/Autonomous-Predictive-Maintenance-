import { useState } from 'react';
import { EquipmentMonitor } from './components/equipment-monitor';
import { ServiceScheduler } from './components/service-scheduler';
import { PredictiveAnalytics } from './components/predictive-analytics';
import { FeedbackLoop } from './components/feedback-loop';
import { AlertPanel } from './components/alert-panel';
import { Activity, Calendar, TrendingUp, RefreshCw } from 'lucide-react';

type TabType = 'monitor' | 'schedule' | 'analytics' | 'feedback';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('monitor');

  const tabs = [
    { id: 'monitor' as TabType, label: 'Equipment Monitor', icon: Activity },
    { id: 'schedule' as TabType, label: 'Service Schedule', icon: Calendar },
    { id: 'analytics' as TabType, label: 'Predictive Analytics', icon: TrendingUp },
    { id: 'feedback' as TabType, label: 'Feedback Loop', icon: RefreshCw },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-gray-900">Autonomous Predictive Maintenance</h1>
              <p className="text-gray-500 text-sm mt-1">
                Proactive Service Scheduling with Manufacturing Feedback Loop
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-600">System Active</span>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex gap-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-1 py-4 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content Area */}
          <div className="lg:col-span-2">
            {activeTab === 'monitor' && <EquipmentMonitor />}
            {activeTab === 'schedule' && <ServiceScheduler />}
            {activeTab === 'analytics' && <PredictiveAnalytics />}
            {activeTab === 'feedback' && <FeedbackLoop />}
          </div>

          {/* Sidebar - Alert Panel */}
          <div className="lg:col-span-1">
            <AlertPanel />
          </div>
        </div>
      </main>
    </div>
  );
}
